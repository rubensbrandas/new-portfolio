## Placeholders

Contains placeholder items such as logos, images etc. for reuse