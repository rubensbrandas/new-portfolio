## SaaS website templates

Free SaaS templates

The names don't mean much, you can use any templates for your purpose

### Finance template
This is a simple landing page

[Live preview](https://finance-saas-template.netlify.app/)

![finance landing page](./screenshots/finance.png) - 

### Celestial SaaS Theme landing page

[Live preview](https://celestialsaas.netlify.app/)

![Celestial landing page](./screenshots/celestialsaas.png) 


### AI SaaS landing page

[Live preview](https://ai-code.netlify.app/)

![Ai SaaS landing page](./screenshots/ai-saas.png) 

### SaaSy Dark landing page

[Live preview](https://saasy-dark.netlify.app/)

![Saasy Dark landing page](./screenshots/saasydark.png) 

### Pixa AI

This one has both dark and light theme, feel free to try it out.

[Live preview](https://pixapage.netlify.app/)

![Pixa Landing page](./screenshots/pixa-dark.png) 


#tailwind templates #website templates