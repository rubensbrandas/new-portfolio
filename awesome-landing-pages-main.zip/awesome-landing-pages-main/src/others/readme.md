## Other website templates

Free website templates

The names don't mean much, you can use any templates for your purpose

### Supreme Carwash website template
This is a simple landing page for car wash

[Live preview](https://supremecarwash.netlify.app/)

![finance landing page](./screenshots/carwash.png) - 

### Celestial SaaS Theme landing page

[Live preview](https://celestialsaas.netlify.app/)

![finance landing page](./screenshots/celestialsaas.png) 


#tailwind templates #website templates