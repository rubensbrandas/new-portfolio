## Restaurant website landing pages

Free restaurant templates

The names don't mean much, you can use any templates for your purpose

### Bistro

[Live preview](https://bistro-rest.netlify.app/)

![restaurant landing page](./screenshots/bistro.png) - 


### Nutrio

[Live preview](https://nutrio-rest.netlify.app/)

![restaurant landing page](./screenshots/nutrio.png) 




#tailwind templates #website templates