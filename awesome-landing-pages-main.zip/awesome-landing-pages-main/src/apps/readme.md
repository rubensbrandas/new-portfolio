## App website landing pages

Free app templates

The names don't mean much, you can use any templates for your purpose

### ChatOrigin landing page

[Live preview](https://chatorigin.netlify.app/)

![app landing page](./screenshots/chat-origin.png) - 


### AISales

[Live preview](https://aisales-app.netlify.app/)

![app landing page](./screenshots/aisales.png) - 


### Navigator

[Live preview](https://navigator-app.netlify.app/)

![app landing page](./screenshots/navigator.png) - 

### Traveler

[Live preview](https://traveler-dyno.netlify.app/)

![app landing page](./screenshots/traveler.png) - 



#tailwind templates #website templates