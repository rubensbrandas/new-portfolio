## Restaurant website landing pages

Free restaurant templates

The names don't mean much, you can use any templates for your purpose

### Brick landing page

[Live preview](https://brickproperty.netlify.app/)

![realestate landing page](./screenshots/brickstone.png) - 


#tailwind templates #website templates