## NGO website landing pages

Free Ngo templates

The names don't mean much, you can use any templates for your purpose

### Project Africa

[Live preview](https://law-fire.netlify.app/)

![law fire landing page](./screenshots/project-africa.png) - 


#tailwind templates #website templates #law website