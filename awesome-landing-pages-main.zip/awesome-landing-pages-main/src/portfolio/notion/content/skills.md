## My skills

* Reactjs
* Django
* AWS
* Python
* Javascript
* Tailwind Css
