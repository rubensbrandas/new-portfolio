## portfolio website landing pages

Free portfolio templates

The names don't mean much, you can use any templates for your purpose

### Bella youtuber landing page

[Live preview](https://bella-youtuber.netlify.app/)

![portfolio landing page](./screenshots/bella.png) - 


#tailwind templates #website templates


### Jrdev - Developers portfolio
This is a multi-themed portfolio, easily switch between multiple themes

[Live preview](jrdev-port.netlify.app)

![portfolio landing page](./screenshots/dev.png) - 

### Notion portfolio

[Live preview](https://notion-portfolio.netlify.app/)

![notion portfolio landing page](./screenshots/notion.png) - 


### Jamie Portfolio

[live preview](https://jamie-dev-portfolio.netlify.app/)

![developer portfolio](./screenshots/jamie-dev-portfolio.png)