## Lawyer website landing pages

Free lawyer templates

The names don't mean much, you can use any templates for your purpose

### LawGroup

[Live preview](https://lawgroup.netlify.app/)

![lawgroup landing page](./screenshots/lawgroup.png) - 


### Law Fire

[Live preview](https://law-fire.netlify.app/)

![law fire landing page](./screenshots/law-fire.png) - 


#tailwind templates #website templates #law website